package com.sdl.AUAS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuasApplicationTests {

	@Test
	void contextLoads() {
	}

}
