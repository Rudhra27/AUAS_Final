package com.sdl.AUAS.Model;

import java.util.Arrays;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Type;

@Entity
@Table (name="personalinfo")
public class Personalinfo {
	
	@Id
	//(strategy = GenerationType.AUTO)
	@GeneratedValue(strategy = GenerationType.AUTO)
	//@SequenceGenerator(name="product_generator", sequenceName = "product_seq")
	private long id;
	
	
	private long userid;
	
	private String place;
	@Column(name="Time")
	 @Temporal(TemporalType.TIMESTAMP)
	    private Date utilDate;
	
		private String query;
		
	@Lob
	
	  @Column(name = "image")
	  private byte[] image;
	private String status;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getUserid() {
		return userid;
	}
	public void setUserid(long userid) {
		this.userid = userid;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public Date getUtilDate() {
		return utilDate;
	}
	public void setUtilDate(Date utilDate) {
		this.utilDate = utilDate;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public byte[] getImage() {
		return image;
	}
	public void setImage(byte[] image) {
		this.image = image;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "Personalinfo [id=" + id + ", userid=" + userid + ", place=" + place + ", utilDate=" + utilDate
				+ ", query=" + query + ", image=" + Arrays.toString(image) + ", status=" + status + "]";
	}
	public Personalinfo(long id, long userid, String place, Date utilDate, String query, byte[] image, String status) {
		super();
		this.id = id;
		this.userid = userid;
		this.place = place;
		this.utilDate = utilDate;
		this.query = query;
		this.image = image;
		this.status = status;
	}
	
	public Personalinfo()
	{
		
	}
	
	
	
}