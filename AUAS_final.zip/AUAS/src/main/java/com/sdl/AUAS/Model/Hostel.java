package com.sdl.AUAS.Model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name="hostel")
public class Hostel {
	
	@Id
	//(strategy = GenerationType.AUTO)
	@GeneratedValue(strategy = GenerationType.AUTO)
	//@SequenceGenerator(name="product_generator", sequenceName = "product_seq")
	private long id;
	private long userid;
	
	private String place;
	private String blname;
	private String query;
	 private Date utilDate;
	private String status;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getUserid() {
		return userid;
	}
	public void setUserid(long userid) {
		this.userid = userid;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public String getBlname() {
		return blname;
	}
	public void setBlname(String blname) {
		this.blname = blname;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public Date getUtilDate() {
		return utilDate;
	}
	public void setUtilDate(Date utilDate) {
		this.utilDate = utilDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public Hostel(long id, long userid, String place, String blname, String query, Date utilDate, String status) {
		super();
		this.id = id;
		this.userid = userid;
		this.place = place;
		this.blname = blname;
		this.query = query;
		this.utilDate = utilDate;
		this.status = status;
	}
	@Override
	public String toString() {
		return "Hostel [id=" + id + ", userid=" + userid + ", place=" + place + ", blname=" + blname + ", query="
				+ query + ", utilDate=" + utilDate + ", status=" + status + "]";
	}
	public Hostel()
	{
		
	}
	

}
