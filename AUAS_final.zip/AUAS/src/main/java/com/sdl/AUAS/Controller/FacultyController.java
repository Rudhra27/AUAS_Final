package com.sdl.AUAS.Controller;

import java.sql.Timestamp;

import javax.mail.MessagingException;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.sdl.AUAS.Model.Department;
import com.sdl.AUAS.Model.Facultyid;
import com.sdl.AUAS.Model.General;
import com.sdl.AUAS.Model.Generalinfo;
import com.sdl.AUAS.Model.Library;
import com.sdl.AUAS.Model.Libraryinfo;
import com.sdl.AUAS.Model.Personalinfo;
import com.sdl.AUAS.Model.User;
import com.sdl.AUAS.Repository.DepartmentRepo;
import com.sdl.AUAS.Repository.FacultyidRepo;
import com.sdl.AUAS.Repository.GeneralRepo;
import com.sdl.AUAS.Repository.GeneralinfoRepo;
import com.sdl.AUAS.Repository.LibraryRepo;
import com.sdl.AUAS.Repository.LibraryinfoRepo;
import com.sdl.AUAS.Repository.PersonalinfoRepo;
import com.sdl.AUAS.Repository.UserRepository;
import com.sdl.AUAS.Service.PersonalService;
import com.sdl.AUAS.Service.UserService;

@Controller
public class FacultyController {
	
	

	@Autowired
	FacultyidRepo facultyrepo;
	@Autowired
	DepartmentRepo deptrepo;
	@Autowired
	GeneralRepo grepo;

	PersonalService personalservice;
	@Autowired
	PersonalinfoRepo personalrepo;
	@Autowired
	GeneralinfoRepo ginforepo;
	@Autowired
	LibraryinfoRepo libinforepo;
	@Autowired
	LibraryRepo librepo;
	@Autowired
	UserRepository repo;
	UserService userservice;
	
	@GetMapping("/addFaculty")
	public String signup()
	{
		return "users/FacultySignup";
	}
	@GetMapping("/LoginFaculty")
	public String login()
	{
		return "users/Faculty";
	}

	
	@PostMapping("/addFaculty")
	public String addFaculty(@Valid @ModelAttribute("user") User user,BindingResult br, Model model) {
		
		User user1= new User();
		user1=repo.findByUserid(user.getUserid());
		if(null!=user1)
		{
			String errormsg = "UserId already exist!";
			model.addAttribute("errormsg" , errormsg);
			return "users/FacultySignup";
			//br.rejectValue("userid", "error.user","UserId already exist.");		
		}
		else {
				Facultyid faculityid1 = new Facultyid();
				faculityid1 = facultyrepo.findByFacultyid(user.getUserid());
				if (null == faculityid1 )
					{
						String errormsg = "UserId does not exist!";
						model.addAttribute("errormsg" , errormsg);
						return "users/FacultySignup";
			//br.rejectValue("userid", "error.user","UserId does not exist.");		
					}
			
				else {
					if (user.getName().equals(faculityid1.getName())) {
						repo.save(user);
						String errormsg = "Registered Successfully!";
						model.addAttribute("errormsg" , errormsg);
					return "users/Faculty";
					}
					
					else 
					{
				
						String errormsg = "UserName is not matched with UserId!";
						model.addAttribute("errormsg" , errormsg);
						return "users/FacultySignup";
				//br.rejectValue("name", "error.user","UserName is not matched.");		
					}
			
				}
		 
		}
		
	}
	@GetMapping("/FQuery")
	public String FQuery(@RequestParam("userid") Long passuserid,User user, Model model)
	{
		
		model.addAttribute("passuserid", passuserid);
		return "users/FacultyQuery";
	}
	@PostMapping("/LoginFaculty")  
	public String LoginFaculty(@Valid @ModelAttribute("user") User user, Model model)
	{
		User user1=new User();
		user1=repo.findByUserid(user.getUserid());
		
		Long passuserid = user.getUserid();
		if(null!=user1)
		{
			if(user1.getPassword().equals(user.getPassword())) {
				model.addAttribute("passuserid", passuserid);
					return "users/QuerytypeFaculty";
					}
			else
			{
				String error = "Incorrect Password!";
				model.addAttribute("error" , error);
				return "users/Faculty";
			}
					
		}
		else
		{
			String error = "Invalid ID!";
			model.addAttribute("error" , error);
			return "users/Faculty";
		}
		
	}
	@GetMapping("/postQueries")
	public String postQueries(@RequestParam("userid") Long passuserid,User user, Model model)
	{
		//Long passuserid= user.getUserid();
		model.addAttribute("passuserid", passuserid);
		return "users/FacultyQuery";
	}

@GetMapping("/postCabin1")
	public String cabin(@RequestParam("userid") Long passuserid,User user, Model model)
	{ 
	//Long passuserid= user.getUserid();
	model.addAttribute("passuserid", passuserid);
	//model.addAttribute("passuserid", passuserid);	
	//@RequestParam(value = "passuserid", required = false) Long passuserid, Model model , Personalinfo personal
	System.out.println(passuserid);
	return "users/cabin";	
	}
/*
 @GetMapping("/postCabin1")
public String cabin(@Valid @ModelAttribute Personalinfo personal , Model model)
{
	Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
	String name = authentication.getName();	
	
	Personalinfo personal1 = (Personalinfo) authentication.getPrincipal();
	Long userId = personal1.getUserid();
	System.out.println(userId);
	model.addAttribute("userId",userId);
	
	Authentication auth = SecurityContextHolder.getContext().getAuthentication();
	Personalinfo personal1=new Personalinfo();
	personal1=(Personalinfo) auth.getDetails();
	Long passuserid1 = personal1.getUserid();
	
return "users/cabin";	
}	@PostMapping(value="/postCabin/{passuserid}")
public String cabin(@PathVariable("passuserid") String passuserid, Model model)
{
	model.addAttribute("passuserid", passuserid);	
return "users/cabin";	
}*/

@PostMapping("/postCabin")
public String postCabin( @Valid @ModelAttribute Personalinfo personal , 
		Model model)
{	
	
	
	Personalinfo p1=new Personalinfo();
	p1=personalrepo.findTopByOrderByIdDesc();
	System.out.println(p1);
	Long userid=personal.getUserid();
	 Timestamp date = new Timestamp(System.currentTimeMillis());
	 personal.setUserid(userid);
		personal.setStatus("Submitted");
		personal.setUtilDate(date);
		personalrepo.save(personal);
		System.out.println(personal);
		Long key =personal.getId();
		System.out.println(key+"null");

		
		
		//dept.setKey(personalrepo.findTopByOrderByIdDesc());
		Department dept=new Department();
		dept.setKey(personal.getId());
		dept.setPlace(personal.getPlace());
		dept.setQuery(personal.getQuery());
		dept.setStatus("Received");
		dept.setUtilDate(date);
		deptrepo.save(dept);
		System.out.println(dept);
		String error = "Query Posted Successfully!";
		model.addAttribute("error" , error);
		model.addAttribute("passuserid",userid);
		return "users/FacultyQuery";

		//dept.getImage(personal.getImage());	
		
/*try {
	 	byte[] image = file.getBytes();
	 	dept.setImage(image);
	 	personal.setImage(image);
	 	deptrepo.save(dept);
	 	personalrepo.save(personal);
   try {
	       byte[] encodeBase64 = Base64.getEncoder().encode(image);
	       String base64Encoded = new String(encodeBase64, "UTF-8");
	       model.addAttribute("userImage", base64Encoded );
	     } catch (Exception e) {
	          return "users/cabin";
	      }	     	 	
		int saveImage = personalservice.saveImage(personal);
    if (saveImage == 1) {
//               return "redirect:/";
    	return "redirect:/";
    } else {
        return "users/cabin";
    }
	} catch (Exception e) {
		return "users/cabin";

}*/

	
	
	//return "users/Faculty";
	//,@RequestParam ("photo") MultipartFile file, Model model
	
	//Personalinfo personal2=new Personalinfo();
   
}
@GetMapping("/postLibrary")
public String postLibrary(@RequestParam("userid") Long passuserid,User user, Model model)
{ 
//Long passuserid= user.getUserid();
model.addAttribute("passuserid", passuserid);
//model.addAttribute("passuserid", passuserid);	
//@RequestParam(value = "passuserid", required = false) Long passuserid, Model model , Personalinfo personal
//System.out.println(passuserid);
return "users/FLibrary";	
}
@PostMapping("/postLibraryQuery")
public String postLibraryQuery(Libraryinfo libraryinfo , Model model)
{
	Long userid=libraryinfo.getUserid();
	Timestamp date = new Timestamp(System.currentTimeMillis());
	//Personalinfo personal2=new Personalinfo();
	libraryinfo.setStatus("Submitted");
	libraryinfo.setUtilDate(date);
	libinforepo.save(libraryinfo);
	
	
	Library lib=new Library();
	
	//dept.setKey(personalrepo.findTopByOrderByIdDesc());
	Libraryinfo l1=new Libraryinfo();
	l1=libinforepo.findTopByOrderByIdDesc();
	lib.setKey(l1.getId());
	lib.setAuthor(libraryinfo.getAuthor());
	lib.setBname(libraryinfo.getBname());
	lib.setEdition(libraryinfo.getEdition());
	
	lib.setStatus("Received");
	lib.setUtilDate(date);
	
	//dept.getImage(personal.getImage());
	librepo.save(lib);
	String error = "Query Posted Successfully!";
	model.addAttribute("error" , error);
	model.addAttribute("passuserid",userid);
	return"users/FacultyQuery";
}
@GetMapping("/postGeneral")
public String postGeneral(@RequestParam("userid") Long passuserid,User user, Model model)
{ 
//Long passuserid= user.getUserid();
model.addAttribute("passuserid", passuserid);
//model.addAttribute("passuserid", passuserid);	
//@RequestParam(value = "passuserid", required = false) Long passuserid, Model model , Personalinfo personal
System.out.println(passuserid);
return "users/General";	
}
@PostMapping("/postGeneral")
public String postGeneral(Generalinfo generalinfo , Model model)
{

	Long userid=generalinfo.getUserid();
	Generalinfo g1=new Generalinfo();
	g1=ginforepo.findTopByOrderByGidDesc();
	//,@RequestParam ("photo") MultipartFile file, Model model
	Timestamp date = new Timestamp(System.currentTimeMillis());
	//Personalinfo personal2=new Personalinfo();
	generalinfo.setStatus("Submitted");
	generalinfo.setUtilDate(date);
	generalinfo.setCount(1);
	ginforepo.save(generalinfo);
	//System.out.println(g1.getGid());
	
	General general= new General();
	
	//dept.setKey(personalrepo.findTopByOrderByIdDesc());
	
	general.setGid(g1.getGid());
	general.setPlace(generalinfo.getPlace());
	general.setQuery(generalinfo.getQuery());
	general.setCount(1);
	general.setStatus("Received");
	general.setUtilDate(date);
	
	//dept.getImage(personal.getImage());
	grepo.save(general);
	
	String error = "Query Posted Successfully!";
	model.addAttribute("error" , error);
	model.addAttribute("passuserid",userid);
	
	return "users/FacultyQuery";
}

@GetMapping("/forgotPassword")
public String forgotPassword()
{
	return "users/ForgotPassword";
}
@PostMapping("/SendEmail")
public String sendmail(@Valid @ModelAttribute("user") User user,Model model,ModelAndView modelAndView) throws MessagingException
{
	String mail=user.getEmail();
	User user1= new User();
	user1=repo.findByEmail(user.getEmail());
	if(null!=user1)
	{
		String password=user1.getPassword();
		
		System.out.println("Mailid : "+mail);
		System.out.println("Password : "+password);
		
		//ConfirmationToken confirmationToken = new ConfirmationToken(existingUser);

        // Save it
       // confirmationTokenRepository.save(confirmationToken);

        // Create the email
        SimpleMailMessage mailMessage = new SimpleMailMessage();
        mailMessage.setTo(user.getEmail());
        mailMessage.setSubject("Your Password!");
        mailMessage.setFrom("auasorg@gmail.com");
        mailMessage.setText("Your Password For AUAS is: "
          +user1.getPassword());

        // Send the email
        emailSenderService.sendEmail(mailMessage);

        modelAndView.addObject("message", "Request to reset password received. Check your inbox for the reset link.");
        modelAndView.setViewName("successForgotPassword");

        com.sdl.AUAS.Model.SendEmail sendEmail=new
                com.sdl.AUAS.Model.SendEmail (mail,"Your password is:",password);
		return"users/Faculty";
	}
	else
	{
		String error = "Email ID does not exist!";
		model.addAttribute("error" , error);
		return "users/Faculty";
	}
	
	
	
}
@GetMapping("/goback")
public String goback(@RequestParam("userid") Long passuserid, Model model)
{
	model.addAttribute("passuserid", passuserid);
	
	return "users/QuerytypeFaculty";
}

@GetMapping("/gobackQuery")
public String gobackQuery()
{
	//model.addAttribute("passuserid",passuserid);
	return "users/QuerytypeFaculty";
}

@GetMapping("/signout")
public String signout()
{
	return "users/Faculty";
}

	
@GetMapping("/viewQuery")
public String ViewQuery(Personalinfo personal,Model model)
{
	Long passuserid= personal.getUserid();
	model.addAttribute("passuserid", passuserid);
		
	return "users/MyQuery";
}

@GetMapping("/Support")
public ModelAndView Support()
{
	//model.addAttribute("passuserid",passuserid);
	ModelAndView mav=new ModelAndView("users/GeneralSupport");
	mav.addObject("generals",grepo.findAll());
	return mav;
}

@PostMapping("/increasecount")
public String follow(@RequestParam("gid") Long gid,@Valid @ModelAttribute("general2") General general2, Model model) {
    General general1 = new General();
    //Long lid =generalinfo1.getGid();
    general1 = grepo.findByGid(general2.getGid());


    System.out.println(general2.getGid()+"enterred");
    System.out.println(general1);

    if(null!=general1)
    {

        System.out.println("IN");
        int count=general1.getCount();
        System.out.println("initial "+count);
        count++;
        System.out.println("update "+count);
        model.addAttribute("count" , count);
        general1.setCount(count);
        grepo.save(general1);
        return "redirect:/Support";
    }
    else

        return "redirect:/";
  }
}
/*@GetMapping("/myCabin")
public ModelAndView myCabin(Model model , Personalinfo personal) {
	
	Long passuserid=personal.getUserid();
	ModelAndView mav = new ModelAndView("users/MyCabin");
	//Personalinfo personal2 = personalrepo.findByUserid(passuserid);
	
	
	
   // List<Personalinfo> queries = new ArrayList<>();
    List<Personalinfo> anotherList = Arrays.asList(personalrepo.findByUserid(passuserid));
    Map<Integer, String, String, String> map = new HashMap<Integer, String, String, String>(); 
    for (Personalinfo personal1 : anotherList) { 

        map.put(personal1.getId(), personal1.getPlace(),personal1.getQuery(),personal1.getStatus()); 

    } 
   // queries.addAll(anotherList);
    mav.addAllObjects(map);
   
	System.out.println(passuserid+"entered");
	
	System.out.println(map);
	
	return mav;
	}
}

@GetMapping("/myCabin")
public String myCabin(@Valid @ModelAttribute Model model , Personalinfo personal) {
	
	List<Personalinfo> Personals = new ArrayList<Personalinfo>();
	Long passuserid=personal.getUserid();
	
    Personals = personalrepo.findAll(personalrepo.findByUserid(passuserid));
    
	 //List<Personalinfo> Personals = Arrays.asList(personalrepo.findByUserid(passuserid));
	 
	 	System.out.println(passuserid+"entered");
	 	
		 model.addAllAttributes(Personals);
	
	System.out.println(model);
	
	return "users/MyCabin" + Personals ;
	}
}*/
/*
 * 
 * 
 * @GetMapping("/myCabin")
public ModelAndView myCabin(Personalinfo personal) {
	ModelAndView mav = new ModelAndView("users/MyCabin");
	Long passuserid=personal.getUserid();
	
	
	System.out.println(passuserid+"entered");
	mav.addObject("Personals",personalrepo.findByUserid(passuserid));
	System.out.println(mav);
	
	return mav;
	}
}
@GetMapping("/myCabin")
public List<Personalinfo> myCabin(Personalinfo personal)  
{  
	query = personal.createQuery("SELECT instrument from Instrument instrument where instrument.User_ID=:User_ID",Personalinfo.class);
  query.setParameter("User_ID", User_ID);

  List<Instrument> instruments=  query.getResultList();

  for(Instrument instrument:instruments){
           System.out.println("Instrument ID  "+instrument.getID());
             // using sysout as it is not prod code yet
       }
}


	 * @GetMapping("/facultylist") public String getFaculty() { Facultyid
	 * faculityid=new Facultyid(); ArrayList<Facultyid> facultylist=new
	 * ArrayList<Facultyid>(); facultylist=(ArrayList<Facultyid>)
	 * facultyrepo.findAll();
	 * System.out.println("values from faculty table:"+facultylist);
	 * Map<Long,Facultyid > map = new HashMap<Long,Facultyid>(); for (Facultyid
	 * facultyid : facultylist) { map.put(facultyid.getFacultyid(), facultyid); }
	 * System.out.println("values stored to map:"+map);
	 * faculityid=map.get(user.getUserid());
	 * System.out.println("name :"+faculityid.getName());
	 * 
	 * }
	 */
	// System.out.println(user);
	// model.addAttribute("user", user);
	// Long id=user.getUserid();
	// if (id.equals(Facultyid.getFacultyid()))






