package com.sdl.AUAS.Model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="facultyid")
public class Facultyid {
	

	@Id
	public Long facultyid;
	public String name;
	public Facultyid()
	{
		
	}
public Long getFacultyid() {
		return facultyid;
	}
public String getName() {
return name;
}

public void setName(String name) {
this.name = name;
}
	public void setFacultyid(Long facultyid) {
		this.facultyid = facultyid;
	}
	@Override
	public String toString() {
		return "Facultyid [facultyid=" + facultyid + ", name=" + name + "]";
	}
	

}
