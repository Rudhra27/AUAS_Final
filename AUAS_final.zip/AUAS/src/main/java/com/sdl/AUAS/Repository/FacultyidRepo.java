package com.sdl.AUAS.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sdl.AUAS.Model.Facultyid;
@Repository
public interface FacultyidRepo extends JpaRepository<Facultyid,Long>{

	Facultyid findByFacultyid(Long userid);

}
