package com.sdl.AUAS.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sdl.AUAS.Model.Studentid;
@Repository
public interface StudentidRepo extends JpaRepository<Studentid,Long>{

	Studentid findByStudentid(Long sid);

}
