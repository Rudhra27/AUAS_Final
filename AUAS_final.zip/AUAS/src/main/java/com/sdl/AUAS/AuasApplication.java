package com.sdl.AUAS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuasApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuasApplication.class, args);
	}

}
