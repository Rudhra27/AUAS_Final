package com.sdl.AUAS.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sdl.AUAS.Model.General;

@Repository
public interface GeneralRepo extends JpaRepository<General,Long>{

	General findByGid(long gid);
	

}
