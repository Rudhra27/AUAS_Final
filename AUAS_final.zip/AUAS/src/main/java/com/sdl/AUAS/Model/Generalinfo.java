package com.sdl.AUAS.Model;

import java.util.Arrays;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table (name="deptgeneral")
public class Generalinfo {

	@Id
	
	//@SequenceGenerator(name="product_generator", sequenceName = "product_seq")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long gid;
	 private long userid;
	@Column(name="Time")
	 @Temporal(TemporalType.TIMESTAMP)
	    private Date utilDate;
	private String place;
		private String query;
	@Lob
	  @Column(name = "image")
	  private byte[] image;
	private int count;
	private String status;
	
	
	public long getGid() {
		return gid;
	}
	public void setGid(long gid) {
		this.gid = gid;
	}
	public long getUserid() {
		return userid;
	}
	public void setUserid(long userid) {
		this.userid = userid;
	}
	public Date getUtilDate() {
		return utilDate;
	}
	public void setUtilDate(Date utilDate) {
		this.utilDate = utilDate;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public byte[] getImage() {
		return image;
	}
	public void setImage(byte[] image) {
		this.image = image;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	@Override
	public String toString() {
		return "Generalinfo [gid=" + gid + ", userid=" + userid + ", utilDate=" + utilDate + ", place=" + place
				+ ", query=" + query + ", image=" + Arrays.toString(image) + ", count=" + count + ", status=" + status
				+ "]";
	}
	
	
	public Generalinfo(long gid, long userid, Date utilDate, String place, String query, byte[] image, int count,
			String status) {
		super();
		this.gid = gid;
		this.userid = userid;
		this.utilDate = utilDate;
		this.place = place;
		this.query = query;
		this.image = image;
		this.count = count;
		this.status = status;
	}
	public Generalinfo()
	{
		
	}
	
}
