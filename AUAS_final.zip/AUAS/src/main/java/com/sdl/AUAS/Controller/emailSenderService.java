package com.sdl.AUAS.Controller;

import org.springframework.mail.SimpleMailMessage;

public class emailSenderService {

	

	
	public static void main(String[] args)
    {
        com.sdl.AUAS.Model.SendEmail sendEmail=new
            com.sdl.AUAS.Model.SendEmail ("Selvasneha07@gmail.com","password","1234");
    }

	public static void sendEmail(SimpleMailMessage mailMessage) {
		// TODO Auto-generated method stub
		
	}
	
}
