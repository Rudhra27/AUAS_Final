package com.sdl.AUAS.Controller;

import java.sql.Timestamp;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.sdl.AUAS.Model.Department;
import com.sdl.AUAS.Model.General;
import com.sdl.AUAS.Model.Generalinfo;
import com.sdl.AUAS.Model.Library;
import com.sdl.AUAS.Model.Libraryinfo;
import com.sdl.AUAS.Model.Personalinfo;
import com.sdl.AUAS.Model.Staff;
import com.sdl.AUAS.Model.Staffid;
import com.sdl.AUAS.Model.User;
import com.sdl.AUAS.Repository.DepartmentRepo;
import com.sdl.AUAS.Repository.GeneralRepo;
import com.sdl.AUAS.Repository.GeneralinfoRepo;
import com.sdl.AUAS.Repository.LibraryRepo;
import com.sdl.AUAS.Repository.LibraryinfoRepo;
import com.sdl.AUAS.Repository.PersonalinfoRepo;
import com.sdl.AUAS.Repository.StaffRepo;
import com.sdl.AUAS.Repository.StaffidRepo;
import com.sdl.AUAS.Service.UserService;
@Controller
public class StaffController {
	

	@Autowired
	StaffidRepo staffidrepo;
	@Autowired
	DepartmentRepo deptrepo;
	@Autowired
	PersonalinfoRepo personalrepo;

	@Autowired
	GeneralinfoRepo ginforepo;
	
	@Autowired
	GeneralRepo grepo;
	
	@Autowired
	StaffRepo staffrepo;
	
	@Autowired
	LibraryinfoRepo libinforepo;
	@Autowired
	LibraryRepo librepo;
	
	UserService userservice;

	@GetMapping("/addStaff")
	public String signup()
	{
		return "staff/StaffSignup";
	}
	@GetMapping("/LoginStaff")
	public String login()
	{
		return "staff/Staff";
	}
	
	@PostMapping("/addStaff")
	public String addFaculty(@RequestParam("sfid") Long sfid, Staff staff,BindingResult br, Model model) {

	
		Staff staff1= new Staff();
		staff1=staffrepo.findByUserid(sfid);
		System.out.println(sfid);
		if(null!=staff1)
		{
			String errormsg = "UserId already exist!";
			model.addAttribute("errormsg" , errormsg);
			return "staff/StaffSignup";		
		}
		
		else {
		Staffid staffid1 = new Staffid();
		staffid1 = staffidrepo.findByStaffid(sfid);
		if (null == staffid1 )
		{
			String errormsg = "UserId does not exist!";
			model.addAttribute("errormsg" , errormsg);
			return "staff/StaffSignup";
			//br.rejectValue("userid", "error.user","UserId does not exist.");
			
		}
		
		else {
			if (staff.getSfname().equals(staffid1.getStaffName())) {
				staffrepo.save(staff);
				String errormsg = "Registered Successfully!";
				model.addAttribute("errormsg" , errormsg);
				return "staff/Staff";
			} else {
				String errormsg = "UserName is not matched with UserId!";
				model.addAttribute("errormsg" , errormsg);
				return "staff/StaffSignup";
				//br.rejectValue("name", "error.user","UserName is not matched.");		
			}
			
		}
		}
	}
	@GetMapping("/SfQuery")
	public String FQuery(@RequestParam("userid") Long passuserid,Staff staff, Model model)
	{
		
		model.addAttribute("passuserid", passuserid);
		return "staff/StaffQuery";
	}

	@PostMapping("/LoginStaff")
	public String LoginFaculty(@RequestParam("sfid") Long sfid,@Valid @ModelAttribute("staff") Staff staff, Model model)
	{
		Staff staff1= new Staff();
		staff1=staffrepo.findByUserid(staff.getUserid());
		//Long passuserid = staff.getUserid();
		if(null!=staff1)
		{
			if(staff1.getSfpassword().equals(staff.getSfpassword()))
			{
				model.addAttribute("passuserid", sfid);
					return "staff/QuerytypeStaff";
			}
			else
			{
				String error = "Incorrect Password!";
				model.addAttribute("error" , error);
				return "staff/Staff";
			}
					
		}
		else
		{
			String error = "Invalid ID!";
			model.addAttribute("error" , error);
			return "staff/Staff";
		} 
	}
	@GetMapping("/postQueriesSf")
	public String postQueries(@RequestParam("userid") Long passuserid,Staff staff, Model model)
	{
		//Long passuserid= staff.getUserid();
		model.addAttribute("passuserid", passuserid);
		return "staff/StaffQuery";
	}
	@GetMapping("/postOffice")
	public String cabin(@RequestParam("userid") Long passuserid,Staff staff, Model model)
	{ 
	//Long passuserid= staff.getUserid();
	model.addAttribute("passuserid", passuserid);
	//model.addAttribute("passuserid", passuserid);	
	//@RequestParam(value = "passuserid", required = false) Long passuserid, Model model , Personalinfo personal
	System.out.println(passuserid);
	return "staff/Office";	
	}
	@PostMapping("/postOffice")
	public String postOffice(Personalinfo personal,Model model)
			 
	{
		Personalinfo p1=new Personalinfo();
		p1=personalrepo.findTopByOrderByIdDesc();

		Long userid=personal.getUserid();
		//,@RequestParam ("photo") MultipartFile file, Model model
		Timestamp date = new Timestamp(System.currentTimeMillis());
		
		//Personalinfo personal2=new Personalinfo();
		personal.setStatus("Submitted");
		personal.setUtilDate(date);
		personalrepo.save(personal);
		
		
		Department dept=new Department();
		
		//dept.setKey(personalrepo.findTopByOrderByIdDesc());
		
		dept.setKey(p1.getId());
		dept.setPlace(personal.getPlace());
		dept.setQuery(personal.getQuery());
		dept.setStatus("Received");
		dept.setUtilDate(date);
		
		//dept.getImage(personal.getImage());
		deptrepo.save(dept);
		String error = "Query Posted Successfully!";
		model.addAttribute("error" , error);
		model.addAttribute("passuserid",userid);
		return "staff/StaffQuery";
	}
	
	@GetMapping("/postGeneralSf")
	public String postGeneral(@RequestParam("userid") Long passuserid,Staff staff, Model model)
	{ 
	//Long passuserid= staff.getUserid();
	model.addAttribute("passuserid", passuserid);
	//model.addAttribute("passuserid", passuserid);	
	//@RequestParam(value = "passuserid", required = false) Long passuserid, Model model , Personalinfo personal
	System.out.println(passuserid);
	return "staff/GeneralSf";	
	}
	@PostMapping("/postGeneralSf")
	public String postGeneralSf(Generalinfo generalinfo, Model model)
	{

		Generalinfo g1=new Generalinfo();
		g1=ginforepo.findTopByOrderByGidDesc();
		//,@RequestParam ("photo") MultipartFile file, Model model
		Timestamp date = new Timestamp(System.currentTimeMillis());
		//Personalinfo personal2=new Personalinfo();
		generalinfo.setStatus("Submitted");
		generalinfo.setUtilDate(date);
		generalinfo.setCount(1);
		ginforepo.save(generalinfo);
		System.out.println(g1.getGid());
		
		Long userid=generalinfo.getUserid();
		General general= new General();
		
		//dept.setKey(personalrepo.findTopByOrderByIdDesc());
		
		general.setGid(g1.getGid());
		general.setPlace(generalinfo.getPlace());
		general.setQuery(generalinfo.getQuery());
		general.setCount(1);
		general.setStatus("Received");
		general.setUtilDate(date);
		
		//dept.getImage(personal.getImage());
		grepo.save(general);
		

		String error = "Query Posted Successfully!";
		model.addAttribute("error" , error);
		model.addAttribute("passuserid",userid);
		
		return "staff/StaffQuery";
	}
	
	@GetMapping("/postLibrarySf")
	public String postLibrary(@RequestParam("userid") Long passuserid,Staff staff, Model model)
	{ 
	//Long passuserid= staff.getUserid();
	model.addAttribute("passuserid", passuserid);
	//model.addAttribute("passuserid", passuserid);	
	//@RequestParam(value = "passuserid", required = false) Long passuserid, Model model , Personalinfo personal
	//System.out.println(passuserid);
	return "staff/SfLibrary";	
	}
	@PostMapping("/postLibraryQuerySf")
	public String postLibraryQuery(Libraryinfo libraryinfo, Model model)
	{
		Timestamp date = new Timestamp(System.currentTimeMillis());
		//Personalinfo personal2=new Personalinfo();
		libraryinfo.setStatus("Submitted");
		libraryinfo.setUtilDate(date);
		libinforepo.save(libraryinfo);
		Long userid=libraryinfo.getUserid();
		
		Library lib=new Library();
		
		//dept.setKey(personalrepo.findTopByOrderByIdDesc());
		Libraryinfo l1=new Libraryinfo();
		l1=libinforepo.findTopByOrderByIdDesc();
		lib.setKey(l1.getId());
		lib.setAuthor(libraryinfo.getAuthor());
		lib.setBname(libraryinfo.getBname());
		lib.setEdition(libraryinfo.getEdition());
		
		lib.setStatus("Received");
		lib.setUtilDate(date);
		
		//dept.getImage(personal.getImage());
		librepo.save(lib);
		String error = "Query Posted Successfully!";
		model.addAttribute("error" , error);
		model.addAttribute("passuserid",userid);
		return"staff/StaffQuery";
	}

	@GetMapping("/signoutSf")
	public String signout()
	{
		return "staff/Staff";
	}

	@GetMapping("/gobackSf")
	public String gobackSf(@RequestParam("userid") Long passuserid, Model model)
	{
		model.addAttribute("passuserid", passuserid);
		
		return "staff/QuerytypeStaff";
	}

	@GetMapping("/SupportSf")
	public ModelAndView SupportSf()
	{
		//model.addAttribute("passuserid",passuserid);
		ModelAndView mav=new ModelAndView("staff/GeneralSupportStaff");
		mav.addObject("generals",grepo.findAll());
		return mav;
	}

	@PostMapping("/increasecountSf")
	public String follow(@RequestParam("gid") Long gid,@Valid @ModelAttribute("general2") General general2, Model model) {
	    General general1 = new General();
	    //Long lid =generalinfo1.getGid();
	    general1 = grepo.findByGid(general2.getGid());


	    System.out.println(general2.getGid()+"enterred");
	    System.out.println(general1);

	    if(null!=general1)
	    {

	        
	        int count=general1.getCount();
	       
	        count++;
	      
	        model.addAttribute("count" , count);
	        general1.setCount(count);
	        grepo.save(general1);
	        return "redirect:/SupportSf";
	    }
	    else

	        return "redirect:/";
	  }
	
}
