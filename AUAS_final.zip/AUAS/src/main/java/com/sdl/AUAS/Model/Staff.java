package com.sdl.AUAS.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity	
@Table(name="staff", schema="public")
public class Staff {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private Long userid;
	private String sfname;
	private String sfemail;
	private String sfpassword;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public Long getUserid() {
		return userid;
	}
	public void setUserid(Long userid) {
		this.userid = userid;
	}
	public String getSfname() {
		return sfname;
	}
	public void setSfname(String sfname) {
		this.sfname = sfname;
	}
	public String getSfemail() {
		return sfemail;
	}
	public void setSfemail(String sfemail) {
		this.sfemail = sfemail;
	}
	public String getSfpassword() {
		return sfpassword;
	}
	public void setSfpassword(String sfpassword) {
		this.sfpassword = sfpassword;
	}
	
	
	public Staff(int id, Long userid, String sfname, String sfemail, String sfpassword) {
		super();
		this.id = id;
		this.userid = userid;
		this.sfname = sfname;
		this.sfemail = sfemail;
		this.sfpassword = sfpassword;
	}
	public Staff()
	{
		
	}
	@Override
	public String toString() {
		return "Staff [id=" + id + ", userid=" + userid + ", sfname=" + sfname + ", sfemail=" + sfemail
				+ ", sfpassword=" + sfpassword + "]";
	}
	
	
}
