package com.sdl.AUAS.Controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.sdl.AUAS.Model.Admin;
import com.sdl.AUAS.Model.General;
import com.sdl.AUAS.Model.Hostel;
import com.sdl.AUAS.Model.Libraryinfo;
import com.sdl.AUAS.Repository.AdminRepo;
import com.sdl.AUAS.Repository.GeneralRepo;
import com.sdl.AUAS.Repository.HostelRepo;
import com.sdl.AUAS.Repository.LibraryRepo;
import com.sdl.AUAS.Repository.LibraryinfoRepo;

@Controller
public class AdminController {
	

	@Autowired
	AdminRepo arepo;
	@Autowired 
	 LibraryRepo libRepo;
	@Autowired 
	 LibraryinfoRepo lRepo;
	@Autowired 
	GeneralRepo gRepo;
	@Autowired 
	HostelRepo hRepo;
	
	@PostMapping("/LoginAdmin")
	public String LoginAdmin(@Valid @ModelAttribute("admin") Admin admin, Model model)
	{
		Admin admin1=new Admin();
		
		
		
		admin1=arepo.findByAdid(admin.getAdid());
		if(null!=admin1)
		{
			if(admin.getAdpassword().equals(admin1.getAdpassword()))
					
			{
				if(admin.getAdid()==1000000001)
				{
					return "admin/dpselect";
				}
				if(admin.getAdid()==1000000002)
				{
					return "admin/HostelOffice";
				}
				if(admin.getAdid()==1000000003)
				{
					return "admin/libselect";
				}
			}
			else
			{
				String error = "Incorrect Password!";
				model.addAttribute("error" , error);
				return "admin/AdminLogin";
			}
					
		}
		else
		{
			String error = "Invalid ID!";
			model.addAttribute("error" , error);
			return "admin/AdminLogin";
		}
		return "admin/AdminLogin";
	}
	
	@GetMapping(value="/Dept")
	public ModelAndView Dept()
	{
		ModelAndView mav = new ModelAndView();
		mav.addObject("departments",gRepo.findAll());
		mav.setViewName("admin/DeptOffice");
		return mav;
	}
//Dept change status page
	@PostMapping("/Dept")
	public String follow(@RequestParam("gid") Long gid,@Validated @ModelAttribute("general2") General general2, Model model) {
	    General general1 = new General();
	    //Long lid =generalinfo1.getGid();
	    general1 = gRepo.findByGid(general2.getGid());

	    System.out.println(general2.getGid()+"enterred");
	    System.out.println(general1);

	    if(null!=general1)
	    {

	        
	        general1.setStatus("Solved");
	        gRepo.save(general1);
	        return "redirect:/Dept";
	    }
	    else
	        return "redirect:/";
	  }
@GetMapping("/gobackQueryd")
	public String gobackQueryd()
	{
		//model.addAttribute("passuserid",passuserid);
		return "admin/dpselect";
	}
//dept sign out
	@GetMapping("/signoutd")
	public String signoutd()
	{
		return "admin/AdminLogin";
	}
//Library Select Query PAge
		@GetMapping(value="/LibQ")
		public ModelAndView LibQ()
		{
			ModelAndView mav = new ModelAndView();
			mav.addObject("library",lRepo.findAll());
			mav.setViewName("admin/Library");
			return mav;
		}

//Library change status page
			@PostMapping("/LibQ")
			public String libq(@RequestParam("id") Long id,@Validated @ModelAttribute("libinfo2") Libraryinfo libinfo2, Model model) {
			   Libraryinfo libinfo1  = new Libraryinfo(); 
			   libinfo1 = lRepo.findById(libinfo2.getId());

			   System.out.println(libinfo2.getId()+"enterred");
			    System.out.println(libinfo1);
			    if(null!=libinfo1)
			    {

			        
			        libinfo1.setStatus("Solved");
			        lRepo.save(libinfo1);
			        return "redirect:/LibQ";
			    }
			    else
			        return "redirect:/";
			  }
@GetMapping("/signoutl")
public String signout()
{
	return "admin/AdminLogin";
}

@GetMapping("/gobackQueryl")
public String gobackQuery()
{
	//model.addAttribute("passuserid",passuserid);
	return "admin/libselect";
}
			//Hostel Select Query PAge
				@GetMapping(value="/HosQ")
				public ModelAndView HosQ()
				{
					ModelAndView mav = new ModelAndView();
					mav.addObject("hostel",hRepo.findAll());
					mav.setViewName("admin/HostelOffice");
					return mav;
				}
			//Hostel change status page
				@PostMapping("/HosQ")
				public String hosq(@RequestParam("id") Long id,@Validated @ModelAttribute("hostel2") Hostel hostel2, Model model) {
				   Hostel h1 = new Hostel();
				   h1 = hRepo.findById(hostel2.getId());
				   System.out.println(hostel2.getId()+"entered");
				   System.out.println(h1); 
				     if(null!=h1)
				    {

				        h1.setStatus("Solved");
				        hRepo.save(h1);
				        return "redirect:/HosQ";
				    }
				    else
				        return "redirect:/";
				  }
	

				//hostel sign out
					@GetMapping("/signouth")
					public String signouth()
					{
						return "admin/AdminLogin";
					}


@GetMapping("/gobackQueryh")
public String gobackQueryh()
{
	//model.addAttribute("passuserid",passuserid);
	return "admin/hostelselect";
}
}
