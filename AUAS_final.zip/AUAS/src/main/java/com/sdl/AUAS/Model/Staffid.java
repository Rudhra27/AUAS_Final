package com.sdl.AUAS.Model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity	
@Table(name="staffid", schema="public")
public class Staffid {
	
	@Id
	public Long staffid;
	public String staffName;
	public Long getStaffid() {
		return staffid;
	}
	public void setStaffid(Long staffid) {
		this.staffid = staffid;
	}
	public String getStaffName() {
		return staffName;
	}
	public void setStaffName(String staffName) {
		this.staffName = staffName;
	}
	@Override
	public String toString() {
		return "Staffid [staffid=" + staffid + ", staffName=" + staffName + "]";
	}
	
	

	
}
